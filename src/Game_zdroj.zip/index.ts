import Engine, { EngineConfig, EngineInput, EngineRender, RenderObjectRect } from "./engine.js"

const gameConfig:EngineConfig = {
    functions: {
        ready: (render) => ready(render),
        update: (render,input) => update(render,input)
    }
}

const eng = new Engine()
window.onload = () => {
    const canvasElement: HTMLCanvasElement = (document.getElementById("game") as HTMLCanvasElement);
    const ctx = canvasElement.getContext("2d");
    
    if (ctx != null) {
       eng.init(ctx, gameConfig) 
    } else {
        alert("No canvas")
    }
    
}

// Game
let player:RenderObjectRect = {x: 0, y: 0,w: 50,h:50,color: "white"}

let enemy:RenderObjectRect = {x: 100, y: 100,w: 50,h:50,color: "green"}


const ready = (canvas: EngineRender) => {
    console.log("ready");
    canvas.fillRect(1,1,50,50,"black")
}



const update = (render:EngineRender,input:EngineInput) => {
    
    

    render.fillRect(0,0,render.canvas.width, render.canvas.height,"black")

    render.objectRect(player)
    render.objectRect(enemy)

    let coll = [
        eng.collisions.advancedrect(player,enemy)
    ]
    

    var pvel = {x:0,y:0}

    input.keys.forEach(key => {
        if (key === "ArrowUp") pvel.y = -1
        if (key === "ArrowDown") pvel.y = 1
        if (key === "ArrowLeft") pvel.x = -1
        if (key === "ArrowRight") pvel.x = 1
    });

    
    coll.forEach((cl) => {
        if (cl =="up" && pvel.y < 0) pvel.y = 0
        if (cl =="down" && pvel.y > 0) pvel.y = 0
        if (cl =="left" && pvel.x < 0) pvel.x = 0
        if (cl =="right" && pvel.x > 0) pvel.x = 0
    }
    )


    player.x += pvel.x

    player.y += pvel.y
    
}
    
        

const input = (canvas: CanvasRenderingContext2D, event: KeyboardEvent) => {
    console.log(event.key);
    
}
